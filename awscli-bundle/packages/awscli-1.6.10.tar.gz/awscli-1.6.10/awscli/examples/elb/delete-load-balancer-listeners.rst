**To delete a listener from your load balancer**

This example deletes a listener from your load balancer on the specified port.

Command::

      aws elb delete-load-balancer-listeners --load-balancer-name MyHTTPSLoadBalancer --load-balancer-ports 80


Output::

      {}

