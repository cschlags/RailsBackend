**To add tags for a load balancer**

This example adds tags for a load balancer.

Command::

  aws elb add-tags  --load-balancer-name MyTCPLoadBalancer --tag "Key=project,Value=lima"

Output::

  {}
  
